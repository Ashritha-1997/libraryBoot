package com.capgemini.libraryboot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.libraryboot.model.Book;
import com.capgemini.libraryboot.model.Library;
import com.capgemini.libraryboot.repository.BookRepository;
import com.capgemini.libraryboot.repository.LibraryRepository;
import com.capgemini.libraryboot.service.LibraryServiceImpl;

@RestController
public class LibraryController {
	
	@Autowired
	private BookRepository bookRepo;
	
	@Autowired
	private LibraryRepository libRepo;
	
	@Autowired
	private LibraryServiceImpl service;
	
	@RequestMapping("/")
	public String index() {
		return "index.jsp";
	}
	
	@PostMapping("/addBook")
	public String addBook(Library library, Book book) {
		book.setLibrary(library);
		library.getBook().add(book);
		libRepo.save(library);
		return "added";
	}
		
	@DeleteMapping("/deleteBook")
	public String deleteBook(@RequestParam int bookId) {
			service.deleteBook(bookId);
			return "Deleted";
	}
	
	@RequestMapping(value="/searchBook",method=RequestMethod.GET)
	public ModelAndView searchBook(@RequestParam int libraryId,@RequestParam int bookId) 
	{
		ModelAndView mv=new ModelAndView("searchedBook.jsp");
		Book book=service.searchBook(bookId);
		mv.addObject(book);
		return mv;
	}
		
	
	@PutMapping(value="/updateBook")
	public ModelAndView updateBook(@RequestParam int bookid,@RequestParam String bookName,@RequestParam String author,@RequestParam String publisher) 
	{
		ModelAndView mv=new ModelAndView("updatedBook.jsp");
		Book book=service.updateBook(bookid,bookName,author,publisher);
		mv.addObject(book);
		return mv;
	}
		
		
	
}
