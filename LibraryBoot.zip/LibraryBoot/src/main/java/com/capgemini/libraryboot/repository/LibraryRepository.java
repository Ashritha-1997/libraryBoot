package com.capgemini.libraryboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.libraryboot.model.Library;

public interface LibraryRepository extends JpaRepository<Library, Integer> {

}
